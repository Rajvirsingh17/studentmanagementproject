<!DOCTYPE html>
<html lang-en>
    <title>
        RAJVIR SINGH
    </title>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<body>
    <?php
     $a="Rajvir Singh";
     //echo $a;
     ?>
    <div class="Content" >
    <p>Hi I am <a href="https://www.linkedin.com/in/rajvir-singh-17p12c"><?php echo $a;?></a><br>
    <b>Education:</b>
        <ol>
            <li>Class 10 <b>2019</b>-Scholars Home</li>
            <li>Class 12 <b>2021</b>-Scholars Home</li>
            <li>B.Tech CSE <b>2025</b>-Velore Institute of Technology</li>
        </ol>
    </p>
    <?php
    
    ?>
</div>
</body>
</html>