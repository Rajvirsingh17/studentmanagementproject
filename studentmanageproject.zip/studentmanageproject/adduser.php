<!--Session code-->
<?php
session_start();
include "database.php";?>
<?php
if (!isset($_SESSION['id'])) {         
  header(' location: login.php');
}
?>

<?php
if (isset($_GET['success']) && $_GET['success'] == 1) {
    echo '<div class="success-message" id="success-message">Record has been successfully added!</div>';
}
?>
<!--Insertion Code-->





<!--html code-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Students</title>
    
    <link rel="stylesheet" href="css/adduser.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
</head>
<body>
<!--navbar-->
<div class="container-fluid" id="navbar-container">
        
    <nav class="dashboard-nav">
        <ul>
            <li><a href="dashboard.php" class="navbar-link"><i class="fa fa-home"></i>Home</a></li>
            <li><a href="faculties.php" class="navbar-link"><i class="fa fa-ravelry"></i>Faculty</a></li>
            <li><a href="adduser.php" class="navbar-link active"><i class="fa fa-plus"></i>Add Student</a></li>
            <li><a href="viewuser.php" class="navbar-link"><i class="fa fa-graduation-cap"></i>View Students</a></li>
            <li>
                <a href="courses.php"><i class="fa fa-book"></i>Courses</a>
                   
            </li>
            <li><a href="logout.php"  name="signout" id="signout" class="signout-btn">Log Out</a></li>
        </ul>
    </nav>
</div>

<!-- Registration_page-->

<h1 class="form-head">STUDENT DETAILS</h1>
    <form id="addstudent-form" method="POST" action="addnewstudent.php" class="needs-validation border p-4">

        <div class="row">
            <div class="mb-3 col-md-4">
                <label for="name" class="form-label">Name<span class="required">*</span></label>
                <input type="text" class="form-control" id="name" name="name" required>
                <div class="invalid-feedback" id="name-error"></div></div>
            <div class="mb-3 col-md-4">
                <label for="father-name" class="form-label">Father's Name<span class="required">*</span></label>
                <input type="text" class="form-control" id="father-name" name="father-name" required>
                <div class="invalid-feedback" id="father-name-error"></div></div>
                <div class="col-md-4 mb-3">
    <label for="gender">Gender</label>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="gender" id="male" value="male" required>
        <label class="form-check-label" for="male">Male</label>
    </div>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="gender" id="female" value="female" required>
        <label class="form-check-label" for="female">Female</label>
    </div>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="gender" id="other" value="other" required>
        <label class="form-check-label" for="other">Other</label>
    </div>


                <div class="invalid-feedback" id="gender-error"></div>
            </div>
</div>
            <div class="row">
            <div class="mb-3 col">
                <label for="email" class="form-label">Email Address</label>
                <input type="email" class="form-control" id="email" name="email">
                <div class="invalid-feedback" id="email-error"></div>
            </div>
            <div class="mb-3 col">
                <label for="phone" class="form-label">Phone Number</label>
                <input type="tel" class="form-control" minlength=10 maxlength=10 id="phone" name="phone" pattern="[0-9]{10}" placeholder="10 digits">
                <div class="invalid-feedback" id="phone-error"></div>
            </div>

            <div class="mb-3 col">
                <label for="address" class="form-label">Address<span class="required">*</span></label>
                <input type="text" class="form-control" id="address" name="address" required>
                <div class="invalid-feedback" id="address-error"></div>
            </div>
            </div>
            <div class="row">
            <div class="mb-3 col-md-4">
                <label for="cgpa" class="form-label">CGPA<span class="required">*</span></label>
                <input type="number" step="0.01" class="form-control" placeholder="Enter CGPA" id="cgpa" name="cgpa" required>
                <div class="invalid-feedback" id="cgpa-error"></div>
                </div>
                <div class="mb-3 col-md-4">
                <label for="course" class="form-label">Course opted<span class="required">*</span></label>
                <select class="form-control" id="course" name="course" required>
                    <optgroup label="Computer Science Engineering">
                        <option value="CSE Core">CSE Core</option>
                        <option value="CSE Data Science">CSE Data Science</option>
                        <option value="CSE Information Securit">CSE Information Security</option>
                        <option value="CSE Blockchain">CSE Blockchain</option>
                        <option value="CSE Business Systems">CSE Business Systems</option>
                        <option value="CSE Bioinformatics">CSE Bioinformatics</option>
                    </optgroup>
                <option value="Mechanical Engineering">Mechanical Engineering</option>
                <option value="Electrical Engineering">Electrical Engineering</option>
                <option value="Electronic Engineering">Electronic Engineering</option>
                <option value="Civil Engineering">Civil Engineering</option>
</select>
                <div class="invalid-feedback" id="course-error"></div>
                </div>
                <div class="col-md-4 mb-3">
    <label for="feepaid">FEE PAID</label>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="feepaid" id="yes" value="yes" required>
        <label class="form-check-label" for="yes">Yes</label>
    </div>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="feepaid" id="no" value="no" required>
        <label class="form-check-label" for="no">No</label>
    </div>
</div>
</div>
<div class="row">
<div class="mb-3 col">
                <label for="studentid" class="form-label">Student ID<span class="required">*</span></label>
                <input type="text" class="form-control" id="studentid" name="studentid" required>
                <div class="invalid-feedback" id="studentid-error"></div>
            </div>
                <div class="mb-3 col">
                <label for="entry-year" class="form-label">Year of Admission<span class="required">*</span></label>
                <select class="form-control" id="entry-year" name="entry-year" required>
                <?php
                $currentYear = date("Y");
                for ($i = $currentYear; $i >= $currentYear - 50; $i--) {
                    echo "<option value='$i'>$i</option>";
                }
                ?></select>
<div class="invalid-feedback" id="entryyear-error"></div>               
 </div>
<div class="mb-3 col">
    <label for="graduate-year" class="form-label">Year of Graduation<span class="required">*</span></label>
    <select class="form-control" id="graduate-year" name="graduate-year" required>
    <?php
                $currentYear = date("Y");
                for ($i = $currentYear; $i <= $currentYear + 50; $i++) {
                    echo "<option value='$i'>$i</option>";
                }
                ?>

</select>
<div class="invalid-feedback" id="graduate-year-error"></div>
</div>
</div>

            <button type="submit" id="submit" name="submit" class="btn btn-primary">Submit</button><br><br>
    
            <button type="reset" id="reset" class="btn btn-secondary">Reset</button>
</form>
<script src="js/adduser.js"></script>


</body>
</html>
