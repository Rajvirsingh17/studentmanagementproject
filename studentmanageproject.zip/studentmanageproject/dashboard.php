<!--Session code-->
<?php
session_start();
include "database.php";?>
<?php
if (!isset($_SESSION['id'])) {         
  header('location: login.php');
}
?>
<?php
if (isset($_POST['signout'])) {
    session_destroy(); 
    echo '<script>alert("Session Ended")</script>';           
    header('refresh:0','url: login.php');
  }
  ?>
<?php
$sql="select count(*) as studno from student_details";
$q=$conn->prepare($sql);
$q->execute();
$result1=$q->fetch(PDO::FETCH_ASSOC);?>

<?php
$sql2="select count(*) as subno from courses";
$q=$conn->prepare($sql2);
$q->execute();
$result2=$q->fetch(PDO::FETCH_ASSOC);?>

<?php
$sql3="select count(*) as feepaid from student_details where feepaid='no'";
$q=$conn->prepare($sql3);
$q->execute();
$result3=$q->fetch(PDO::FETCH_ASSOC);?>

<?php
$sql4="select count(distinct faculty) as facultyno from courses";
$q=$conn->prepare($sql4);
$q->execute();
$result4=$q->fetch(PDO::FETCH_ASSOC);?>

<?php
$sql5="select count(distinct year_entry) as batches from student_details ";
$q=$conn->prepare($sql5);
$q->execute();
$result5=$q->fetch(PDO::FETCH_ASSOC);?>


<!--html code-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/dashboardstyle.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    
</head>
<body>
  <!--Navbar container-->
    <div class="container-fluid" id="navbar-container">
        
    <nav class="dashboard-nav">
        <ul>
            <li><a href="dashboard.php" class="navbar-link active"><i class="fa fa-home"></i>Home</a></li>
            <li><a href="faculties.php" class="navbar-link"><i class="fa fa-ravelry"></i>Faculty</a></li>
            <li><a href="adduser.php" id="add-user-btn" class="navbar-link"><i class="fa fa-plus"></i>Add Student</a></li>
            <li><a href="viewuser.php" id="view-user-btn" class="navbar-link"><i class="fa fa-graduation-cap"></i>View Students</a></li>
            <li>
                <a href="courses.php"><i class="fa fa-book"></i>Courses</a>
                   
            </li>
            <form class="logout" id="logout" method="POST">
            <li><button type="submit" name="signout" id="signout" class="signout-btn">Log Out</button></li></form>
        </ul>
    </nav>
</div>


<!--Dashboard display-->
<div id="dashboard-class" class="container-fluid">
    <h1 class="heading-1">Welcome <?php echo $_SESSION["name"];?>!</h1>
    <h4 class="heading-4"><a href="profile.php?id=<?php echo $_SESSION["id"]; ?>"><i class="fa fa-user-circle"></i><?php echo  " ".$_SESSION['email']; ?></a></h4> 
</div>





<div class="card" id="student-card">
  <div class="card-info">
    <p class="nos">
    <?php echo $result1["studno"];?></p>
    <p>No. of Students</p>
  </div>
</div>
<div class="card" id="subject-card">
  <div class="card-info">
    <p class="nos">
    <?php echo $result2["subno"];?></p>
    <p>No. of Subjects</p>
  </div>
</div>
<div class="card" id="fee-card">
  <div class="card-info">
    <p class="nos">
    <?php echo $result3["feepaid"];?></p>
    <p>Fee pending</p>
  </div>
</div>

<div class="card" id="faculty-card">
  <div class="card-info">
    <p class="nos">
    <?php echo $result4["facultyno"];?></p>
    <p>Faculty</p>
  </div>
</div>

<div class="card" id="batches-card">
  <div class="card-info">
    <p class="nos">
    <?php echo $result5["batches"];?></p>
    <p>Batches</p>
  </div>
</div>



 
</body>
</html>
       