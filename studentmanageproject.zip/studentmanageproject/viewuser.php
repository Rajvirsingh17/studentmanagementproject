<!--Session code-->
<?php
session_start();
include "database.php";?>
<?php
if (!isset($_SESSION['id'])) {         
  header('location: login.php');
}
?>
<!--logout code-->
<?php
if (isset($_POST['signout'])) {
    session_destroy(); 
    echo '<script>alert("Session Ended")</script>';           
    header('refresh:0','location: login.php');
  }
  ?>

<!--Updation with subject names-->
<?php
$q = $conn->query("SELECT id, course FROM student_details");
    $students = $q->fetchAll(PDO::FETCH_ASSOC);

    foreach ($students as $student) {
        $coursesub = $student['course'];
        $q = $conn->prepare("SELECT subname FROM courses WHERE course = :course");
        $q->bindParam(':course', $coursesub);
        $q->execute();
        $subjects = $q->fetchAll(PDO::FETCH_ASSOC);

        // Extract subject names
        $subjectNames = [];
        foreach ($subjects as $subject) {
            $subjectNames[] = $subject['subname'];
        }

        // Encode subject names as JSON
        $jsonSubjects = json_encode($subjectNames);

        // Update the student_details table with JSON subjects
        $q = $conn->prepare("UPDATE student_details SET subjects_json = :jsonSubjects WHERE id = :Id");
        $q->bindParam(':jsonSubjects', $jsonSubjects);
        $q->bindParam(':Id', $student['id']);
        $q->execute();
    }
    ?>

<!--selection of data-->
<?php
error_reporting(E_ERROR | E_PARSE);
include "database.php";
//for search button
if(isset($_POST['search'])){
try{
$searchvalue=$_POST["searchvalue"];
$sql= "SELECT * from student_details where studentid like '%$searchvalue%' student_name like '%$searchvalue%' or father_name like '%$searchvalue%' or
 email like '%$searchvalue%' or phone like '%$searchvalue%' or s_address like '%$searchvalue%'";
$q=$conn->prepare($sql);
$q-> execute();
$result=$q->fetchAll();
}
catch(PDOException $e){
  echo "Could not show";
}}

//for filter button
else if(isset($_POST["filter"])){
try{
  $gendersearch=$_POST["gender"];
  $mincgpa=$_POST["mincgpa"];
  $maxcgpa=$_POST["maxcgpa"];
  $course=$_POST["course"];
  $feepaid=$_POST["feepaid"];
  $entryyear=$_POST["entryyear"];
  $gradyear=$_POST["graduate-year"];
  $sql2="SELECT * from student_details";
  $conditions=[];
  
  //conditions 
  if(!empty($gendersearch)){
    $conditions[]="gender=?";
   
  }
  if(!empty($course)){
    $conditions[]="course=?";
   
  }
  if(!empty($feepaid)){
    $conditions[]="feepaid=?";
   
  }
  if(!empty($entryyear)){
    $conditions[]="year_entry=?";
   
  }
  if(!empty($gradyear)){
    $conditions[]="year_grad=?";
   
  }
  if(!empty($mincgpa)){
    $conditions[]="cgpa >= ?";
    
  }
  if(!empty($maxcgpa)){
    $conditions[]="cgpa <= ?";

  }
  if(!empty($conditions)){
    $sql2 .= " WHERE " . implode(" AND ", $conditions);
    $q=$conn->prepare($sql2);
    $params=[];
    //parameters for execution
    if(!empty($gendersearch)){
      $params[]=$gendersearch;
    }
    if(!empty($course)){
      
      $params[]=$course;
    }
    if(!empty($feepaid)){
   
      $params[]=$feepaid;
    }
    if(!empty($entryyear)){
    
      $params[]=$entryyear;
    }
    if(!empty($gradyear)){
 
      $params[]=$gradyear;
    }
    if(!empty($mincgpa)){
    
      $params[]=$mincgpa;
    }
    if(!empty($maxcgpa)){
   
      $params[]=$maxcgpa;
    }
   
    $q->execute($params);
    
  }
  else{
    $q->execute();
    
  }
  $result=$q->fetchAll();
 } 
 catch(PDOException $e){
  echo "Could not Show";
 }
}
else{
    $sql= 'SELECT * from student_details';
    $q=$conn->prepare($sql);
    $q-> execute();
    $result=$q->fetchAll();
}  
?>



<!--html code-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>view students</title>
    <link rel="stylesheet" href="css/viewuser.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    
</head>
<body>

  <!--Navbar container-->
    <div class="container-fluid" id="navbar-container">
        
    <nav class="dashboard-nav">
        <ul>
           
            <li><a href="dashboard.php" class="navbar-link"><i class="fa fa-home"></i>Home</a></li>
            <li><a href="faculties.php" class="navbar-link"><i class="fa fa-ravelry"></i>Faculty</a></li>
            <li><a href="adduser.php" id="add-user-btn" class="navbar-link"><i class="fa fa-plus"></i>Add Student</a></li>
            <li><a href="viewuser.php" id="view-user-btn" class="navbar-link active" ><i class="fa fa-graduation-cap"></i>View Students</a></li>
            <li>
                <a href="courses.php"><i class="fa fa-book"></i>Courses</a>
                   
            </li>
            <form class="logout" id="logout" method="POST">
            <li><button type="submit" name="signout" id="signout" class="signout-btn">Log Out</button></li></form>
        </ul>
    </nav>
</div>

<!--Sidebar for filters and searching-->

<div class="sidebar" id="sidebarfilter" >
  

<form id="filter-form" method="POST">
    
                <div class=" mb-3">
    <label for="gender">Gender</label>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="gender" id="male" value="male" >
        <label class="form-check-label" for="male">Male</label>
    </div>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="gender" id="female" value="female">
        <label class="form-check-label" for="female">Female</label>
    </div>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="gender" id="other" value="other" >
        <label class="form-check-label" for="other">Other</label>
    </div>


                <div class="invalid-feedback" id="gender-error"></div>
            </div>
           
            
            <div class="mb-3 ">
              <label for="cgpa">CGPA</label>
              <div class="row">
                <div class="col-md-6">
                <label for="mincgpa" class="form-label">Min. CGPA</label>
                <input type="number" step="0.01" class="form-control" value=0 placeholder="Enter Min CGPA" id="mincgpa" name="mincgpa">
                </div>
                <div class="col-md-6 ">
                <label for="maxcgpa" class="form-label">Max. CGPA</label>
                <input type="number" step="0.01" class="form-control" value=10 placeholder="Enter Max CGPA" id="maxcgpa" name="maxcgpa">
                </div>
                </div>
                </div>
                <div class="mb-3">
                <label for="course" class="form-label">Course opted</label>
                <select class="form-control" id="course" name="course" >
                <option label=""></option>
                    <optgroup label="Computer Science Engineering">
                        <option value="CSE Core">CSE Core</option>
                        <option value="CSE Data Science">CSE Data Science</option>
                        <option value="CSE Information Securit">CSE Information Security</option>
                        <option value="CSE Blockchain">CSE Blockchain</option>
                        <option value="CSE Business Systems">CSE Business Systems</option>
                        <option value="CSE Bioinformatics">CSE Bioinformatics</option>
                    </optgroup>
                <option value="Mechanical Engineering">Mechanical Engineering</option>
                <option value="Electrical Engineering">Electrical Engineering</option>
                <option value="Electronic Engineering">Electronic Engineering</option>
                <option value="Civil Engineering">Civil Engineering</option>
</select>
                <div class="invalid-feedback" id="course-error"></div>
                </div>
                <div class=" mb-3">
    <label for="feepaid">FEE PAID</label>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="feepaid" id="yes" value="yes">
        <label class="form-check-label" for="yes">Yes</label>
    </div>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="feepaid" id="no" value="no">
        <label class="form-check-label" for="no">No</label>
    </div>
</div>
                
                <div class="mb-3">
                <label for="entry-year" class="form-label">Year of Admission</label>
                <select class="form-control" id="entry-year" name="entry-year" >
                  <option label=""></option>
                <?php
                $currentYear = date("Y");
                for ($i = $currentYear; $i >= $currentYear - 50; $i--) {
                    echo "<option value='$i'>$i</option>";
                }
                ?></select>
<div class="invalid-feedback" id="entryyear-error"></div>               
 </div>
<div class="mb-3">
    <label for="graduate-year" class="form-label">Year of Graduation</label>
    <select class="form-control" id="graduate-year" name="graduate-year" >
    <option label=""></option>
    <?php
                $currentYear = date("Y");
                for ($i = $currentYear; $i <= $currentYear + 50; $i++) {
                    echo "<option value='$i'>$i</option>";
                }
                ?>

</select>
<div class="invalid-feedback" id="graduate-year-error"></div>
</div>

            <button type="submit" id="filter" name="filter" class="btn btn-primary">Filter</button>
    
            <button type="reset" id="reset" class="btn btn-secondary">Reset</button>
</form>
</div>








<!--Show User-->
<div id="show_user" class="container">
<h1 class="table-heading">Students</h1>
<form id="search-form" method="POST">
<div class="mb-3">        
  <input type="search" id="search-bar" name="searchvalue" class="form-control" placeholder="Search">
    <button input type="submit" name="search" id="search">
      <i class="fa fa-search"></i>
    </button>
  </div>
</form>
<div id="filter-button"><button name="hamburg" id="hamburg" onclick="showhidefilter()"><i class="fa fa-filter"></i>Filter</button>
            </div>
<table class="table table-bordered table-condensed">
<?php
if($result){?>
  <thead>
    <tr>
      <th>S.no.</th>
      <th>Student ID</th>
      <th>Name</th>
      <th>Father's Name</th>
      <th>Gender</th>
      <th>Email Address</th>
      <th>Mobile Number</th>
      <th>Address</th>
      <th>CGPA</th>
      <th>Course</th>
      <th>Fee Paid</th>
      <th>Enrollment Year</th>
      <th>Graduation Year</th>
      <th>Subjects</th>
      <th>Edit</th>
      <th>Delete</th>
    </tr>
  </thead>
  <tbody>
  <?php 
  $i=1;
    foreach($result as $row){?>
                        <tr>
                            <td><?php echo $i++;?></td>
                            <td><?php echo $row['studentid'];?></td>
                            <td><?php echo $row['student_name'];?></td>
                            <td><?php echo $row['father_name'];?></td>
                            <td><?php echo $row['gender']; ?></td>
                            <td><?php echo $row['email'];?></td>
                            <td><?php echo $row['phone']; ?></td>
                            <td><?php echo $row['s_address']; ?></td>
                            <td><?php echo $row['cgpa']; ?></td>
                            <td><?php echo $row['course']; ?></td>
                            <td><?php echo $row['feepaid']; ?></td>
                            <td><?php echo $row['year_entry']; ?></td>
                            <td><?php echo $row['year_grad']; ?></td>
                            <td><?php $subjects_array = json_decode($row["subjects_json"], true);
                            $j=1;
                            foreach ($subjects_array as $subject) {
                               echo $j.".".$subject . "<br>";
                              $j++;} ?></td>

                            <td class="edit-btn"><a href="edit.php?id=<?php echo $row['id']; ?>"><button class="table-change" id="edit">
                            <i class="fa fa-pencil-square-o" ></i>
                            Edit</button></td>
                            <td class="delete-btn"><a href="delete.php?id=<?php echo $row['id']; ?>"><button class="table-change" id="delete">
                            <i class="fa fa-trash"></i>
                             Delete</button></td>  
                        </tr>
                        <?php }
                        }
                        else{
                          $nf= "no students found";}?>
                          <div id="nf"><?php echo $nf;?>
                        
                </tbody>
                
            </table>

</div>
<script>
  function showhidefilter(){
  var targetdiv=document.getElementById("sidebarfilter");
  targetdiv.style.display = (targetdiv.style.display === "none") ? "block" : "none";
  }
  function showhidefilter2(){
  var targetdiv=document.getElementById("sidebarfilter");
  if(targetdiv.style.display="block"){
    targetdiv.style.display="none";
  }
  }
</script>
                        </body>
                        </html>